package com.example.deneme31;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;


public class RecipeListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe_list);

        // Tarifleri listelemek için gerekli işlemleri burada yapabilirsiniz
    }
}
