package com.example.deneme31;

public class Ingredient {
    private String name;
    private int imageResId;
    private String category;
    private boolean isAvailable;

    public Ingredient(String name, int imageResId, String category) {
        this.name = name;
        this.imageResId = imageResId;
        this.category = category;
        this.isAvailable = false;
    }

    public String getName() {
        return name;
    }

    public int getImageResId() {
        return imageResId;
    }

    public String getCategory() {
        return category;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void setAvailable(boolean available) {
        isAvailable = available;
    }
}
