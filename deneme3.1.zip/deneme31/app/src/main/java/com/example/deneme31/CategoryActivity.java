package com.example.deneme31;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class CategoryActivity extends AppCompatActivity {

    private Button btnSebzeler, btnBaharatlar, btnBaklagiller;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category);

        btnSebzeler = findViewById(R.id.btnSebzeler);
        btnBaharatlar = findViewById(R.id.btnBaharatlar);
        btnBaklagiller = findViewById(R.id.btnBaklagiller);

        btnSebzeler.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CategoryActivity.this, ItemListActivity.class);
                intent.putExtra("CATEGORY", "Sebzeler");
                startActivity(intent);
            }
        });

        btnBaharatlar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CategoryActivity.this, ItemListActivity.class);
                intent.putExtra("CATEGORY", "Baharatlar");
                startActivity(intent);
            }
        });

        btnBaklagiller.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CategoryActivity.this, ItemListActivity.class);
                intent.putExtra("CATEGORY", "Baklagiller");
                startActivity(intent);
            }
        });
    }
}
