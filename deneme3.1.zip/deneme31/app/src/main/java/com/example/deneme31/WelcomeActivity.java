package com.example.deneme31;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Handler;
import android.widget.TextView;



public class WelcomeActivity extends AppCompatActivity {

    private TextView tvWelcomeMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        tvWelcomeMessage = findViewById(R.id.tvWelcomeMessage);

        Intent intent = getIntent();
        String name = intent.getStringExtra("USER_NAME");
        tvWelcomeMessage.setText(name + ", büyük mutfağına hoşgeldiniz!");

        // 3 saniye sonra üçüncü aktiviteye geçiş
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(WelcomeActivity.this, MainScreenActivity.class);
                startActivity(intent);
                finish();
            }
        }, 3000); // 3000 milisaniye = 3 saniye
    }
}
