package com.example.deneme31;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;


import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ItemListActivity extends AppCompatActivity {

    private TextView tvCategory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_list);

        tvCategory = findViewById(R.id.tvCategory);

        String category = getIntent().getStringExtra("CATEGORY");
        if (category != null) {
            tvCategory.setText("Seçilen Kategori: " + category);
        }
    }
}
